export default interface WebService {
    readonly app: any;
    start: any;
}