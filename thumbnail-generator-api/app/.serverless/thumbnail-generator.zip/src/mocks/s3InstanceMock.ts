export default {
    upload: () => (
        {
            promise: () => (
                {
                    Location: 'url'
                }
            )
        }
    )
}