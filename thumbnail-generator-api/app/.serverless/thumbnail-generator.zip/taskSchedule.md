## Agenda

# Day 1
- [x] planing what to do ~30min
- [x] create aws account, get/config credentials and a create bucket ~20min
- [x] create project - uning my own npm package npx create-node-ts-project ~2min (just the time to install the deps)
- [x] install and review new dependencies ~30min
- [x] implement http server 10min
- [x] test upload file with express + express-fileupload ~2h
- [x] setup and implement s3 instance ~45min
- [x] implement and test s3 upload ~2h
- [x] decide which resize buffer to use ~35min
- [x] imlement resize image ~30min
- [x] eventually plus 30% of the total time things over solution hipothesis (brainstorming)

## Day 2

- [x] cleaning the code 1h
- [x] refactoring - identifying and turn block into functions 2h

## Day 3

- [x] implement tests for Image and Storage 2h

- [x] refactoring 2h
- [x] implement new tests for Image and Storage 2h
- [x] mock, integration tests and dependency injection 3h

## Day 4

- [x] refactor env 1h
- [x] fix env mock 2.5h
- [x] write env tests 1.5h
- [x] write tests for web service and implement webs service 5h

day5

| Task                                     | Time    |
| ---------------------------------------- | ------- |
| Uncouple web service from route handlers | 02:30hs |
| Implement app.start test                 | 01:00hs |
| Refactor and implement new tests         | 04:30hs |
| TOTAL                                    | 08:00hs |

day 6

| Task                                             | Time    |
| ------------------------------------------------ | ------- |
| Refactor little test details                     | 01:00hs |
| Write resizeToThreeDimensionsController tests    | 01:30hs |
| Refactor resizeToThreeDimensionsController tests | 03:30hs |
| Implement and test deploy to lambda              | 02:40hs |
| Fix file-type and mimetype to work on lambda     | 03:00hs |
| TOTAL                                            | 11:04hs |

day 7

| Task                                             | Time    |
| ------------------------------------------------ | ------- |
| Create aws-lambda-resize-image library           | 03:00hs |
| Refactor in general                              | 01:45hs |
| TOTAL                                            | 04:45hs |




My mistakes

- attributed wrong commit type tittles. For example, chore: refactor image should be refactor: create Image protocol.

To Improve
about the dependencies, in a daily basis I would like to dicuss with the team which dependencies worth it do adopt and which not. 

Concerns
I would improve the in-memory resized image buffers. 

- I would improve the file/folder structure by discussing with the team about the architecture and patterns adopted 